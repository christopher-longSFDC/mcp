#  License

Use of this software and the Marketing Cloud Personalization service is for demoing features and is subject to the [Personalization terms of use](https://www.salesforce.com/content/dam/web/en_us/www/documents/legal/terms-of-use-evergage.pdf?red=evergage.com&_ga=2.148926257.686475364.1724780080-126587494.1724780080&_gl=1*1w2g6jl*_ga*MTI2NTg3NDk0LjE3MjQ3ODAwODA.*_ga_NLXVJP63NM*MTcyNDc4NTcyOS4xMy4xLjE3MjQ3OTA1MTkuMC4wLjA.).
